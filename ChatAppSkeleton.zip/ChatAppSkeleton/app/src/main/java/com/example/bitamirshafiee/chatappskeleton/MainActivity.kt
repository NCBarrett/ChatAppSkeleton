package com.example.bitamirshafiee.chatappskeleton

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
//import com.firebase.ui.database.FirebaseRecyclerAdapter //problem line

class MainActivity : AppCompatActivity() {

//    private var firebaseAdapter: FirebaseRecyclerAdapter? = null  //problem line

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
